package com.demo.bean;

public class LoginBean {
String user,pass,roll;

public LoginBean() {
}

public LoginBean(String user, String pass, String roll) {
	this.user = user;
	this.pass = pass;
	this.roll = roll;
}

public String getUser() {
	return user;
}

public void setUser(String user) {
	this.user = user;
}

public String getPass() {
	return pass;
}

public void setPass(String pass) {
	this.pass = pass;
}

public String getRoll() {
	return roll;
}

public void setRoll(String roll) {
	this.roll = roll;
}

@Override
public String toString() {
	return "LoginBean [user=" + user + ", pass=" + pass + ", roll=" + roll + "]";
}

}
