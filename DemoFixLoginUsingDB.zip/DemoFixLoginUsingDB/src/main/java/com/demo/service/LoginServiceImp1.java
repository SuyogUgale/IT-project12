package com.demo.service;

import com.demo.bean.LoginBean;
import com.demo.doa.LoginDoa;
import com.demo.doa.LoginDoaImp1;

public class LoginServiceImp1 implements LoginService{

	LoginDoa logindao=new LoginDoaImp1();
	@Override
	public LoginBean validateUser(String user, String pass) {
		// TODO Auto-generated method stub
		return logindao.validateUser(user, pass);
	}
	public LoginBean register(String user, String pass,String role) {
		// TODO Auto-generated method stub
		return logindao.register(user, pass,role);
	}
	public LoginBean changepass(String user, String pass) {
		// TODO Auto-generated method stub
		return logindao.changepass(user, pass);
	}
	
}
