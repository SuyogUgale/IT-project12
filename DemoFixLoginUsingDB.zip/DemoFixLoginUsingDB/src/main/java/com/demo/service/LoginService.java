package com.demo.service;

import com.demo.bean.LoginBean;

public interface LoginService {
	LoginBean validateUser(String user,String pass);
	LoginBean register(String user,String pass,String role);
	LoginBean changepass(String user,String pass);
	
}
