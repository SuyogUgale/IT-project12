package com.demo.doa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.bean.LoginBean;

public class LoginDoaImp1 implements LoginDoa{

	@Override
	public LoginBean validateUser(String user, String pass) {
		// TODO Auto-generated method stub
	LoginBean l=null;
	Connection conn=DBUtil.getCon();
	String query="select * from userdb where username=?"+"and pass=?";
	try
	{
		PreparedStatement stm=conn.prepareStatement(query);
		stm.setString(1, user);
		stm.setString(2, pass);
		ResultSet rs=stm.executeQuery();
	
		if(rs.next())
		{
			
			l=new LoginBean();
			l.setUser(rs.getString(1));
			l.setPass(rs.getString(2));
			l.setRoll(rs.getString(3));
		
	}
	}
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	return l;
	
	}
	public LoginBean register(String user, String pass,String role)
	{
		LoginBean l=null;
		Connection conn=DBUtil.getCon();
		String query="insert into userdb values(?,?,?)";
		try {
			PreparedStatement stm=conn.prepareStatement(query);
			stm.setString(1, user);
			stm.setString(2, pass);
			stm.setString(3, role);
			stm.execute();
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}
	public LoginBean changepass(String user, String pass)
	{
		LoginBean l=null;
		Connection conn=DBUtil.getCon();
		String query="update userdb set pass=? where username=?";
		try {
			PreparedStatement stm=conn.prepareStatement(query);
			stm.setString(1, pass);
			stm.setString(2, user);
			 
			stm.execute();
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}

}
