package com.demo.doa;
import com.demo.bean.*;
public interface LoginDoa {
LoginBean validateUser(String user,String pass);
LoginBean register(String user,String pass,String role);
LoginBean changepass(String user,String pass);
}
