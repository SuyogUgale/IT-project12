package com.demo.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.bean.LoginBean;
import com.demo.service.LoginService;
import com.demo.service.LoginServiceImp1;

/**
 * Servlet implementation class Check
 */
public class Check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("inside service");
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String user=request.getParameter("user");
		String pass=request.getParameter("pass");
		
		RequestDispatcher rd;
		
		LoginService ls=new LoginServiceImp1();
		LoginBean l =ls.validateUser(user, pass);
		if(l!=null)
		{
			if(l.getRoll().equals("user"))
			{
				rd=request.getRequestDispatcher("Userservlet");
				rd.forward(request, response);	
			}
			else
			{
				rd=request.getRequestDispatcher("Adminservlet");
				rd.forward(request, response);		
			}
		}
		else
		{
			out.println("<h3>invalid user</h3>");
			rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);	
		}
		
		
	/*	if(user.equals("devika") && pass.equals("devika"))
		{
			//out.println("welcome");
			rd=request.getRequestDispatcher("User");
			rd.forward(request, response);
		}
		else
		{
			out.println("<h3>invalid user</h3>");
			rd=request.getRequestDispatcher("login1.html");
			rd.include(request, response);
			
		}*/
	
	}

}
